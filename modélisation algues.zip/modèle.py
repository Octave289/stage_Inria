## tentative d'implémentation du modèle stochastique du bassin d'algues
# pas de conditions aux bords ni de condition de non accumulation au niveau 0 (dans la roue à aube)

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.animation import FuncAnimation

def bassin_initial(f, N_lignes, nb_colonnes, l, h):
    delta_x = l/nb_colonnes
    delta_y = h/N_lignes
    X = np.zeros((N_lignes, nb_colonnes))
    for i in range(N_lignes):
        for j in range(nb_colonnes):
            X[i, j] = f(j*delta_x, i*delta_y, l)
    return X

def vecteur_propre(p):
        p_ = np.asarray(p)

        V  = []
        valeurs_propres, vecteurs_propres = np.linalg.eig(p_)

        # Trouver l'indice de la valeur propre la plus proche de 1
        valeurs_propres_translatées = np.real(valeurs_propres - 1)

        vecteur = np.array([0.]*np.shape(p)[0])
        for i in range(len(valeurs_propres_translatées)):
                if np.abs(valeurs_propres_translatées[i]) < 10**(-7):
                        vecteur += vecteurs_propres[:, i] 

        # Normalisation : pour que la somme soit 1 (distribution de probabilité)
        vecteur_normalise = vecteur/sum(v for v in vecteur)

        return vecteur_normalise

def solution_exacte(f, #fonction initiale
                    t, #temps_final
                    N_lignes,
                    nb_colonnes,
                    p,
                    L,
                    H,
                    mu,
                    alpha, beta, gamma
                    ):
    if t == 0 :
        return bassin_initial(f, N_lignes, nb_colonnes, L, H)
    delta_x = L/nb_colonnes
    V = vecteur_propre(p)
    N_max = len(alpha)
    X = np.zeros((N_lignes, nb_colonnes))
    for i in range(N_lignes):
        for col in range(nb_colonnes):
            X[i, col] = sum(alpha[k]*V[i]*np.exp(-4*k**2*np.pi**2*mu/L**2*t)*np.cos(2*k*np.pi*col*delta_x/L)
                            + beta[i][k]*np.exp(-4*k**2*np.pi**2*mu/L**2*t)*np.sin(2*k*np.pi*col*delta_x/L)
                            + gamma[i][k]*np.exp(-(2*k+1)**2*np.pi**2*mu/L**2*t)*np.sin((2*k+1)*np.pi*col*delta_x/L)
                            for k in range(N_max))
    
    return X

def verif_CFL(delta_t, delta_x, mu, u, N_lignes):
    if delta_x*delta_x <= 2*mu*delta_t :
        return False
    else :
        bool = True
        if u != [0]*N_lignes:
            for i in range(N_lignes):
                bool &= delta_x < 2*mu/u[i]
    return bool



import numpy as np

def mise_a_jour(X1, p, N_lignes, nb_colonnes, nu, K):
    X_tmp = np.copy(X1)
    for i in range(N_lignes):
        for j in range(2, nb_colonnes - 1):
            X_tmp[i, j] = (
                (K[i] + nu) * X1[i, j - 1]
                + (1 - 2 * nu) * X1[i, j]
                + (nu - K[i]) * X1[i, j + 1]
            )

        X_tmp[i, nb_colonnes - 1] = (
            (1 - 2 * nu) * X1[i, nb_colonnes - 1]
            + sum((nu - K[l]) * p[i, l] * X1[l, 0] for l in range(N_lignes))
            + (K[i] + nu) * X1[i, nb_colonnes - 2]
        )

        X_tmp[i, 0] = (
            (K[i] + nu) * X1[i, nb_colonnes - 1]
            + sum((1 - 2 * nu) * p[i, l] * X1[l, 0] for l in range(N_lignes))
            + (nu - K[i]) * X1[i, 1]
        )

        X_tmp[i, 1] = (
            (1 - 2 * nu) * X1[i, 1]
            + sum((K[l] + nu) * p[i, l] * X1[l, 0] for l in range(N_lignes))
            + (nu - K[i]) * X1[i, 2]
        )
    return X_tmp


def modèle_stochastique(X, t, N_lignes, nb_colonnes, p, L, H, mu, u, CFL,
                        compare=False, f=None, alpha=None, beta=None, gamma=None):
    delta_x = L / nb_colonnes
    delta_t = CFL * delta_x**2 / mu
    nb_itérations = int(t / delta_t)

    if t == 0:
        return np.copy(X)

    nu = mu * delta_t / (delta_x * delta_x)
    K = [u[i] * delta_t / (2 * delta_x) for i in range(N_lignes)]
    X1 = np.copy(X)

    erreurs = [] if compare else None

    for step in range(nb_itérations + 1):
        X1 = mise_a_jour(X1, p, N_lignes, nb_colonnes, nu, K)
        if compare:
            X_exa = solution_exacte(f, step * delta_t, N_lignes, nb_colonnes,
                                             p, L, H, mu, alpha, beta, gamma)
            erreur = np.max(np.abs(np.array(X_exa).flatten() - X1.flatten()))
            erreurs.append(erreur)

    if t != nb_itérations * delta_t:
        new_delta_t = t - nb_itérations * delta_t
        new_nu = mu * new_delta_t / (delta_x * delta_x)
        new_K = [u[i] * new_delta_t / (2 * delta_x) for i in range(N_lignes)]
        X1 = mise_a_jour(X1, p, N_lignes, nb_colonnes, new_nu, new_K)

    if compare:
        X_exa = solution_exacte(f, t, N_lignes, nb_colonnes,
                                            p, L, H, mu, alpha, beta, gamma)
        erreur = np.max(np.abs(np.array(X_exa).flatten() - X1.flatten()))
        erreurs.append(erreur)
        return X1, np.max(erreurs)
    else:
        return X1


# je construit un autre programme similaire mais qui ne fait qu'une itération en temps :

def modèle_stochastique_une_itération(
                        X,  # tableau des valeurs X_i,j  
                        N_lignes,
                        nb_colonnes,
                        P,
                        L,
                        H,
                        mu,
                        u,
                        CFL
                        ):
    return modèle_stochastique(X, CFL*L*L/(mu*nb_colonnes*nb_colonnes), N_lignes, nb_colonnes, P, L, H, mu, u, CFL)

#il faut à présent appliquer le modèle à quelques exemples que l'on comparera plus tard à l'autre modèle

# On va prendre pour valeurs initiales du tableau X (donc la composition initiale du bassin) celles d'une 
# fonction qu'on aura discrétisée. Par exemple, si l'on prend une fonction affine : f : x, y -> a*x + b*y + c 
# les valeurs des X[i, j] seront celles de la fonction en (i, j)
# prenons pour exemple a = b = c = 1


def modèle_2(X,# tableau des valeurs X_i,j      
            T, #temps_final
            N_lignes,
            nb_colonnes,
            P,
            L,
            H,
            mu,
            u,
            CFL):        
    
    delta_x = L/nb_colonnes
    delta_t = CFL*delta_x**2/mu
    nb_itérations = int(T/delta_t)
    X0 = X
    if T == 0 :
        return X0
    else:
        nu = mu * delta_t / (delta_x * delta_x)
        K = [u[i] * delta_t / (2 * delta_x) for i in range(N_lignes)]

        X1 = np.copy(X0)

        for step in range(nb_itérations + 1):
            X_tmp = np.copy(X1)
            for i in range(N_lignes):
                for j in range(1, nb_colonnes-1):# loin de la roue à aube
                    X_tmp[i, j] = (
                        (K[i] + nu) * X1[i, j - 1]
                        + (1 - 2 * nu) * X1[i, j]
                        + (nu - K[i]) * X1[i, j + 1]
                    )
                X_tmp[i, nb_colonnes - 1] = (
                        (K[i] + nu) * X1[i, nb_colonnes - 2]
                        + (1 - 2 * nu) * X1[i, nb_colonnes - 1]
                        + (nu - K[i]) * X1[i, 0]
                    )
                alpha = sum((nu + K[i])*X1[i, nb_colonnes-1] + (1-2*nu)*X1[i, 0] +(nu - K[i])*X1[i, nb_colonnes-1] for i in range(N_lignes))
                X_tmp[:, 0] = alpha*vecteur_propre(P)


            X1 = X_tmp

        return X1

def modèle_2_une_itération(
                        X,  # tableau des valeurs X_i,j  
                        N_lignes,
                        nb_colonnes,
                        P,
                        L,
                        H,
                        mu,
                        u,
                        CFL
                        ):
    return modèle_2(X, CFL*L*L/(mu*nb_colonnes*nb_colonnes), N_lignes, nb_colonnes, P, L, H, mu, u, CFL)


def X_ini(N_lignes, nb_colonnes):
    X_ini = np.zeros((N_lignes, nb_colonnes))
    for i in range(N_lignes):
        for j in range(nb_colonnes):
            X_ini[i, j] = (i + j / nb_colonnes + 1)
    return X_ini